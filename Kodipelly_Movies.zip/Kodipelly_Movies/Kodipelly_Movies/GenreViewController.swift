//
//  ViewController.swift
//  Kodipelly_Movies
//
//  Created by student on 4/25/22.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        movieslist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = movieslist[indexPath.row].category
        return cell
    }
    
    
   
    @IBOutlet weak var genreTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Movies App"
        // Do any additional setup after loading the view.
        genreTableView.dataSource = self
        genreTableView.delegate = self
    }
    
    var movieslist = moviessectionlist
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            let destination = segue.destination as! MoviesViewController
            destination.movieCategory = movieslist[genreTableView.indexPathForSelectedRow!.row].movies
           
    }

}
}

