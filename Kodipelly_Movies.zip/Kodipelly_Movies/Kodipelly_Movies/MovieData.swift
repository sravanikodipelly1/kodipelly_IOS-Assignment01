//
//  MovieData.swift
//  Kodipelly_Movies
//
//  Created by student on 4/28/22.
//

import Foundation
import UIKit

struct Movie{
    let title:String
    let image:UIImage
    let releasedYear:String
    let movieRating:String
    let boxOffice:String
    let moviePlot:String
    var cast:[String]
}

struct Genre{
    var category:String
    var movies :[Movie] = []
}

let MovieSection1 = Genre(category: "Drama", movies: [Movie(title: "Bheemla Nayak", image:UIImage(named: "Bheemla nayak")!, releasedYear: "2022", movieRating: "6.7",boxOffice: "1.08 million", moviePlot: "Things change when the egos of an upright police officer and a retired army havildar clash.", cast: ["pawan Kalyan", "Nithya Menon"]),Movie(title: "Nanna", image:UIImage(named: "Nanna")!, releasedYear: "2011", movieRating: "8.3", boxOffice: "1.18 million", moviePlot: "a man with an intellectual disability, fights for the custody of his young daughter Nila. He convinces lawyer Anuradha to fight his case when his father-in-law takes his daughter away from him.", cast: ["Vikram","Anushka"]),Movie(title: "Pokiri", image:UIImage(named: "pokiri")!, releasedYear: "2006", movieRating: "7.9", boxOffice: "66 million", moviePlot: "The movie revolves around a criminal who works for the underworld, but secretly is an undercover cop. His dire plan is to bring the don out of his den and kill him.", cast: ["Mahesh Babu", "Trisha"]),Movie(title: "Temper", image:UIImage(named: "temper")!, releasedYear: "2011", movieRating: "7.3", boxOffice: "74.3 million", moviePlot: "Daya, a corrupt police officer, is transferred to Vizag and becomes involved with Walter Vasu, a local crook. When Walter kidnaps Daya's girlfriend, Daya goes to war with Water's criminal empire.", cast: ["NTR","Kajal Agarwal"]),Movie(title: "RRR", image:UIImage(named: "RRR")!, releasedYear: "2022", movieRating: "8.4", boxOffice: "1.15 million", moviePlot: "It is about over caring fatherA tale of two legendary revolutionaries and their journey far away from home. After their journey they return home to start fighting back against British colonialists in the 1920s.", cast: ["NTR", "Ramcharan Tej"])])




let MovieSection2 = Genre(category: "Action", movies: [Movie(title: "Akhanda", image:UIImage(named: "Akhanda")!, releasedYear: "2021", movieRating: "6.9", boxOffice: "20.2 million", moviePlot: "A child is taken in by Aghora, becoming a fierce devotee of Lord Shiva, living up to his destiny to stand tall against evildoers.", cast: ["Bala Krishna", "Pragna Jaswal"]),Movie(title: "Indra", image:UIImage(named: "Indra")!, releasedYear: "2002", movieRating: "7.4", boxOffice: "3.76 million", moviePlot: "A man embarks on a quest to make peace between two families fighting over the water problem in their district. In a bid to solve this crisis, he agrees to marry a girl from the rival family.", cast: ["chiranjeevi", "Sonali Bindre"]),Movie(title: "Bahubali", image:UIImage(named: "bahubali")!, releasedYear: "2015", movieRating: "8.1", boxOffice: "4.15 million", moviePlot: "In the kingdom of Mahishmati, while pursuing his love, Shivudu learns about the conflict ridden past of his family and his legacy. He must now prepare himself to face his newfound arch-enemy.", cast: ["Prabhas", "Anushka"]),Movie(title: "Race gurram", image:UIImage(named: "RaceGurram")!, releasedYear: "2014", movieRating: "7.2", boxOffice: "1.2 million", moviePlot: "Polar opposites in nature, brothers Ram and Lakshman grow up despising one another, their mother wishes to see them united.", cast: ["Allu Arjun","Shruti Hasan"]),Movie(title: "Rarandoi Veduka Chuddam", image:UIImage(named: "Rarandoi")!, releasedYear: "2017", movieRating: "5.7", boxOffice: "1.7 million", moviePlot: "A blossoming romance is derailed by the disapproval of village elders.", cast: ["Naga Chaitanya", "Rakul Preet"])])



let MovieSection3 = Genre(category: "Comedy", movies: [Movie(title: "f2", image:UIImage(named: "f2")!, releasedYear: "2019", movieRating: "6.1", boxOffice: "2.37 million", moviePlot: "Hero’s tell a policeman about their marital troubles; as they tell their own story, they both realise the mistakes of the past and decide to win back their wives.", cast: ["venkatesh", "Varun Tej","Tamannah","Mehreen"]),Movie(title: "Good Luck Sakhi", image:UIImage(named: "goodluck sakhi")!, releasedYear: "2022", movieRating: "7.3", boxOffice: "2.27 million", moviePlot: "Plagued by seemingly endless bad luck, including the accidental death of her fiancé, a young woman trains to compete as a sharpshooter at the national level.", cast: ["Keerthi Suresh", "Aadhi"]),Movie(title: "Prema Katha Chitram", image:UIImage(named: "prema katha chitram")!, releasedYear: "2013", movieRating: "7.1", boxOffice: "2.07 million", moviePlot: "Four friends decide to commit suicide together in a farmhouse because of their failures. A ghost possesses one of the friends and creates havoc in the friends' lives.", cast: ["Sudheer Babu", "Nanditha"]),Movie(title: "Sudigadu", image:UIImage(named: "sudigadu")!, releasedYear: "2012", movieRating: "5.7", boxOffice: "1 million", moviePlot: "hero father and his wife  become the proud parents of a dynamic and powerful new baby who is born with a six pack body. Just when the baby is born, Thikkal Reddy comes in as the villain in search of his enemy who runs into New Born Baby's room.", cast: ["Allari Naresh","Monal Gajjar"]),Movie(title: "Zombie Reddy", image:UIImage(named: "Zombie reddy")!, releasedYear: "2021", movieRating: "6.7", boxOffice: "40 million", moviePlot: "Mario, a game developer, and his friends, get caught up in the rivalry between two families and a mysterious zombie attack in Rayalaseema where they go to attend a friend's wedding.", cast: ["Teja Sajja", "Lahari Sheri"])])

var moviessectionlist = [MovieSection1,MovieSection2,MovieSection3]
