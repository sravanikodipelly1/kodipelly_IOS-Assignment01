//
//  ViewController.swift
//  AnimationDemo
//
//  Created by Kodipelly,Sravani on 3/15/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageviewoutlet: UIImageView!
    
   
    @IBOutlet weak var happyoutlet: UIButton!
    
    @IBOutlet weak var sadoutlet: UIButton!
    
    @IBOutlet weak var Angryoutlet: UIButton!
    
    @IBOutlet weak var shakemeoutlet: UIButton!
    
    @IBOutlet weak var showoutlet: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //move all the components outside the view
        imageviewoutlet.frame.origin.x = view.frame.maxX;
    }
    override func viewDidAppear(_ animated: Bool) {
        //move all the components outside the view
        imageviewoutlet.frame.origin.x = view.frame.maxX;
        happyoutlet.frame.origin.x = view.frame.width;
        sadoutlet.frame.origin.x = view.frame.width;
        Angryoutlet.frame.origin.x = view.frame.width;
        shakemeoutlet.frame.origin.x = view.frame.width;
        
    }
    
    @IBAction func happybuttonclicked(_ sender: UIButton) {
        animateImage("Happy")
    }
    
    @IBAction func sadbuttonclicked(_ sender: UIButton) {
        animateImage("sad")
    }
    
    @IBAction func angrybuttonclicked(_ sender: UIButton) {
        animateImage("Angry")
    }
    
    @IBAction func shakemebuttonclicked(_ sender: Any) {
        var w = imageviewoutlet.frame.width
        w  += 40
        var h = imageviewoutlet.frame.height
        h += 40
        var x = imageviewoutlet.frame.origin.x - 20
        var y = imageviewoutlet.frame.origin.y - 20
        
        var largerframe = CGRect(x: x, y: y, width: w, height: h)
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0,  animations: {
            self.imageviewoutlet.frame = largerframe
        })
    
    }
    
    @IBAction func showbuttonclicked(_ sender: Any) {
        UIView.animate(withDuration: 1, animations: {
            self.imageviewoutlet.center.x = self.view.center.x;
            self.happyoutlet.center.x = self.view.center.x;
            self.sadoutlet.center.x = self.view.center.x;
            self.Angryoutlet.center.x = self.view.center.x;
            self.shakemeoutlet.center.x = self.view.center.x;
            self.showoutlet.isEnabled = false;
        })
    }
        //end showbutton
        func animateImage(_ imageName:String){
            
            //image as opaque
            UIView.animate(withDuration: 1, animations: {
                self.imageviewoutlet.alpha = 0;
            })
            
            UIView.animate(withDuration: 1,delay: 0.2, animations:{
                // make it transparent
                self.imageviewoutlet.alpha = 1 //image transparent
                self.imageviewoutlet.image = UIImage(named: imageName)
            })
            imageviewoutlet.image = UIImage(named: imageName)
            
        
    }
}

