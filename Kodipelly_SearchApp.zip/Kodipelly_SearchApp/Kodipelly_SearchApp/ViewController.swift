//
//  ViewController.swift
//  Kodipelly_SearchApp
//
//  Created by Kodipelly,Sravani on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func searchButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func showNextImagesBtn(_ sender: UIButton) {
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
    }
}

