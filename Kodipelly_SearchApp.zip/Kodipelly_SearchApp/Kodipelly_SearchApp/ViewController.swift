//
//  ViewController.swift
//  Kodipelly_SearchApp
//
//  Created by Student on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

        @IBOutlet weak var searchTextField: UITextField!
        
        @IBOutlet weak var resultImage: UIImageView!
        
        @IBOutlet weak var topicInfoText: UITextView!
        
        @IBOutlet weak var searchButtonAction: UIButton!
        
        @IBOutlet weak var resetButton: UIButton!
        
        @IBOutlet weak var showPrevImagesBtn: UIButton!
        
        @IBOutlet weak var showNextImagesBtn: UIButton!
        
        var arr = [["actor1","actor2","actor3","actor4","actor5"],["flower1","flower2","flower3","flower4","flower5"],["animal1","animal2","animal3","animal4","animal5",],["bg","404"]]
        
        var actors = ["actor","actors","hero","tollywood","nani","anushka shetty","nithin","samantha","vijay devarakonda","celebrity","hero","film"]
        
        var flowers = ["flowers","flower","rose","jasmine","sunflower","lotus","Hibiscus"]
        
        var animals = ["animals","animal", "tiger","rabbit","peacock","monkey","deer"]
        
        var topic = 0
        var imag1:Int!
        var imag2:Int!
        var imag3:Int!
        var name1:Int!
        var name2:Int!
        var name3:Int!
        var text1:Int!
        var text2:Int!
        var text3:Int!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            showPrevImagesBtn.isHidden = true
            showNextImagesBtn.isHidden = true
            searchButtonAction.isEnabled = false
            resetButton.isHidden = true
            resultImage.image = UIImage(named: arr[3][0])
            topicInfoText.text = nil
        }
        
       
    
    @IBAction func searchTextField(_ sender: UITextField) {
        searchButtonAction.isEnabled = true
        if(sender.text == ""){
            searchButtonAction.isEnabled = false
            
        }
        else{
            showPrevImagesBtn.isEnabled = false
            showNextImagesBtn.isEnabled = false
            searchButtonAction.isEnabled = true
            resetButton.isHidden = false
        }
    }
    
        
        var actor = [["Anushka","Nithin","Nani","Vijay Devarakonda","Samantha"],["Anushka Shetty, is an Indian actress and model who predominantly works in the Telugu and Tamil films. She is the recipient of several accolades, including three CineMAA Awards, a Nandi Award, a TN State Film Award and three Filmfare Awards. Having appeared in 47 films, she is one of the highest-paid actresses in India[3] and is popularly referred as Lady Superstar of South Indian cinema.","Nithin Kumar Reddy (born 30 March 1983) known professionally as Nithiin, is an Indian actor and producer who works predominantly in Telugu cinema. Niithin's work has earned him one Filmfare Award and two nominations for the Filmfare Award for Best Actor – Telugu.","Ghanta Naveen Babu (born 24 February 1984), known professionally as Nani, is an Indian actor, producer, and television presenter primarily known for his work in Telugu cinema.","He was the brand ambassador of food delivery app Zomato.On 15 October 2018, Deverakonda launched his fashion brand Rowdy Wear. Later, in 2020 Rowdy Wear was launched on Myntra.","Samantha Ruth Prabhu (formerly Akkineni; born 28 April 1987) is an Indian actress who has established a career in Telugu and Tamil film industries. She is a recipient of several awards, including four Filmfare Awards South, six South Indian International Movie Awards and two Andhra Pradesh State Nandi Awards."]]

        
        var flower = [["Hibiscus","Rose","Jasmine","Lotus","sun flower"],["Hibiscus rosa-sinensis, known colloquially as Chinese hibiscus,[2] China rose,[2] Hawaiian hibiscus,[2] rose mallow[3] and shoeblack plant,[4] is a species of tropical hibiscus, a flowering plant in the Hibisceae tribe of the family Malvaceae. It is widely cultivated as an ornamental plant in the tropics and subtropics, but its native range is Vanuatu ","A rose is a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars.They form a group of plants that can be erect shrubs, climbing, or trailing, with stems that are often armed with sharp prickles. Their flowers vary in size and shape and are usually large and showy, in colours ranging from white through yellows and reds.","Jasmine  is a genus of shrubs and vines in the olive family (Oleaceae). It contains around 200 species native to tropical and warm temperate regions of Eurasia, Africa, and Oceania. Jasmines are widely cultivated for the characteristic fragrance of their flowers.","Lotus plants are adapted to grow in the flood plains of slow-moving rivers and delta areas. Stands of lotus drop hundreds of thousands of seeds every year to the bottom of the pond. While some sprout immediately, and most are eaten by wildlife, the remaining seeds can remain dormant for an extensive period of time as the pond silts in and dries out. During flood conditions, sediments containing these seeds are broken open, and the dormant seeds rehydrate and begin a new lotus colony.","Sunflowers originate in the Americas. They were first domesticated in what is now Mexico and the Southern United States. Domestic sunflower seeds have been found in Mexico, dating to 2100 BCE. Native American people grew sunflowers as a crop from Mexico to Southern Canada. In the 16th century the first crop breeds were brought from America to Europe by explorers."]]


    var animal = [["Deer","Monkey","Peacock","Rabbit","Lion"],["Deer or true deer are hoofed ruminant mammals forming the family Cervidae. The two main groups of deer are the Cervinae, including the muntjac, the elk (wapiti), the red deer, and the fallow deer; and the Capreolinae, including the reindeer (caribou), white-tailed deer, the roe deer, and the moose. Male deer of all species (except the Chinese water deer) as well as female reindeer, grow and shed new antlers each year. In this they differ from permanently horned antelope, which are part of a different family (Bovidae) within the same order of even-toed ungulates (Artiodactyla).","Monkey is a common name that may refer to most mammals of the infraorder Simiiformes, also known as the simians. Traditionally, all animals in the group now known as simians are counted as monkeys except the apes, a grouping known as paraphyletic; however in the broader sense based on cladistics, apes (Hominoidea) are also included, making the terms monkeys and simians synonyms in regard of their scope. Monkeys are divided into the families of New World monkeys (Platyrrhini) and Old World monkactoreys (Cercopithecidae in the strict sense; Catarrhini in the broad sense, which again includes apes).","Peafowl is a common name for three bird species in the genera Pavo and Afropavo within the tribe Pavonini of the family Phasianidae, the pheasants and their allies. Male peafowl are referred to as peacocks, and female peafowl are referred to as peahens, even though peafowl of either sex are often referred to colloquially as peacocks","Male rabbits are called bucks; females are called does. An older term for an adult rabbit used until the 18th century is coney (derived ultimately from the Latin cuniculus), while rabbit once referred only to the young animals.","The tiger has a muscular body with powerful forelimbs, a large head and a tail that is about half the length of its body. Its pelage is dense and heavy, and colouration varies between shades of orange with white ventral areas and distinctive vertical black stripes; the patterns of which are unique in each individual."]]
        
        
        
        @IBAction func searchButtonActionAction(_ sender: UIButton) {
            imag1 = 0
            imag2 = 0
            imag3 = 0
            name1 = 0
            name2 = 0
            name3 = 0
            text1 = 0
            text2 = 0
            text3 = 0
            showPrevImagesBtn.isHidden = false
            showNextImagesBtn.isHidden = false
            showPrevImagesBtn.isEnabled = false
            showNextImagesBtn.isEnabled = false
            resetButton.isEnabled = true
            if(actors.contains(searchTextField.text!)){
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = false
                resultImage.image = UIImage(named: arr[0][imag1])
                topic = 1
                topicInfoText.text = actor[1][text1]
            }
            else if(flowers.contains(searchTextField.text!)){
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = false
                resultImage.image = UIImage(named: arr[1][imag2])
                topic = 2
                topicInfoText.text = flower[1][text2]
            }
            else if(animals.contains(searchTextField.text!)){
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = false
                resultImage.image = UIImage(named: arr[2][imag3])
                topic = 3
                topicInfoText.text = animal[1][text3]
            }
            else{
                resultImage.image = UIImage(named: arr[3][1])
                topicInfoText.text = nil
                showPrevImagesBtn.isHidden = true
                showNextImagesBtn.isHidden = true
                resetButton.isEnabled = true
            }
            
            
        }
        
        @IBAction func showPrevImagesBtn(_ sender: Any) {
            if(topic == 1){
                imag1 -= 1
                name1 -= 1
                text1 -= 1
                dataUpdate(imgNo: imag1)
            }
            if(topic == 2){
                imag2 -= 1
                name2 -= 1
                text2 -= 1
                dataUpdate(imgNo: imag2)
            }
            if(topic == 3){
                imag3 -= 1
                name3 -= 1
                text3 -= 1
                dataUpdate(imgNo: imag3)
            }
            
        }
        
        @IBAction func showNextImagesBtn(_ sender: Any) {
            if(topic == 1){
                imag1 += 1
                name1 += 1
                text1 += 1
                dataUpdate(imgNo: imag1)
            }
            if(topic == 2){
                imag2 += 1
                name2 += 1
                text2 += 1
                dataUpdate(imgNo: imag2)
            }
            if(topic == 3){
                imag3 += 1
                name3 += 1
                text3 += 1
                dataUpdate(imgNo: imag3)
            }
        }
        
        
        @IBAction func resetButton(_ sender: Any) {
            showPrevImagesBtn.isHidden = true
            showNextImagesBtn.isHidden = true
            topicInfoText.text = nil
            searchTextField.text = nil
            resetButton.isHidden = true
            imag1 = 0
            imag2 = 0
            imag3 = 0
            name1 = 0
            name2 = 0
            name3 = 0
            text1 = 0
            text2 = 0
            text3 = 0
            topic = 0
            
            
        }
        
        func dataUpdate(imgNo: Int){
            if(topic == 1){
                if imag1 == arr[0].count-1 {
                    showNextImagesBtn.isEnabled = false
                    showPrevImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[0][imag1])
                    topicInfoText.text = actor[1][text1]
                }
                else if(imag1 == 0){
                    showPrevImagesBtn.isEnabled = false
                    showNextImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[0][imag1])
                    topicInfoText.text = actor[1][text1]
                }
                else{
                    showNextImagesBtn.isEnabled = true
                    showPrevImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[0][imag1])
                    topicInfoText.text = actor[1][text1]
                }
            }
            if(topic == 2){
                if imag2 == arr[1].count-1 {
                    showNextImagesBtn.isEnabled = false
                    showPrevImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[1][imag2])
                    topicInfoText.text = flower[1][text2]
                }
                else if(imag2 == 0){
                    showPrevImagesBtn.isEnabled = false
                    showNextImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[1][imag2])
                    topicInfoText.text = flower[1][text2]
                }
                else{
                    showNextImagesBtn.isEnabled = true
                    showPrevImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[1][imag2])
                    topicInfoText.text = flower[1][text2]
                    
                }
            }
            if(topic == 3){
                if imag3 == arr[1].count-1 {
                    showNextImagesBtn.isEnabled = false
                    showPrevImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[2][imag3])
                    topicInfoText.text = animal[1][text3]
                }
                else if(imag3 == 0){
                    showPrevImagesBtn.isEnabled = false
                    showNextImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[2][imag3])
                    topicInfoText.text = animal[1][text3]
                }
                else{
                    showNextImagesBtn.isEnabled = true
                    showPrevImagesBtn.isEnabled = true
                    resultImage.image = UIImage(named: arr[2][imag3])
                    topicInfoText.text = animal[1][text3]
                    
                }
            }
        }
        

        
        
        
        
        
    }






