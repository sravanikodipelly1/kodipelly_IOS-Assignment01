//
//  ViewController.swift
//  Kodipelly_FormatName
//
//  Created by Kodipelly,Sravani on 1/31/22.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var firstNameTextField: UITextField!
    
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    @IBOutlet weak var DisplayLabel: UILabel!
    
    
    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        var firstnametext=firstNameTextField.text!
        var lastnametext=lastNameTextField.text!
        DisplayLabel.text = "Details"
        fullNameLabel.text = "Full Name: \(firstnametext),\(lastnametext)"
        var initials = firstnametext.prefix(1).uppercased() + lastnametext.prefix(1).uppercased()
        initialsLabel.text = "Initials : \(initials)"
      
        
    }
    
    
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        firstNameTextField.becomeFirstResponder()
        fullNameLabel.text = ""
        initialsLabel.text = ""
    }
    


}

