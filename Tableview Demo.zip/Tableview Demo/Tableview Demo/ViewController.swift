//
//  ViewController.swift
//  Tableview Demo
//
//  Created by Kodipelly,Sravani on 3/29/22.
//

import UIKit
class product{
    var productName : String?
    var productCategory : String?
    
    init(prodName:String, prodCategory:String)
    {
        self.productName = prodName;
        self.productCategory = prodCategory;
    }
    
    
}

class ViewController: UIViewController ,UITableViewDelegate ,
    UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productsArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //return the cell with data
        //create cells
        var cell = tableviewOutlet.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        //assign the data to the cell
        cell.textLabel?.text = productsArray[indexPath.row].productName
        //return cell
        return cell
    }
    
    var productsArray = [product]()
    @IBOutlet weak var tableviewOutlet: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableviewOutlet.delegate = self
        tableviewOutlet.dataSource = self
        
        let product1 = product(prodName:"MacBookAir",prodCategory:"Laptop")
        productsArray.append(product1)
        let product2 = product(prodName:"iphone",prodCategory:"mobile phone")
        productsArray.append(product2)
        let product3 = product(prodName:"Airpods",prodCategory:"Accessories")
        productsArray.append(product3)
        let product4 = product(prodName:"Iwatch",prodCategory:"Aceessories")
        productsArray.append(product4)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "detailsSeque"{
            let destination = segue.destination as!
            DetailsViewController
            
            destination.product = productsArray[(tableviewOutlet.indexPathForSelectedRow?.row)!]
        }
    }
}

