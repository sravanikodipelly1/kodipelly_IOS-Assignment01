//
//  ViewController.swift
//  Kodipelly_Calculator
//
//  Created by Kodipelly,Sravani on 2/17/22.
//

import UIKit

class ViewController: UIViewController {
 
    @IBOutlet weak var displayOutlet: UILabel!
        
        var x : Double = -1.1
        var y : Double = 0
        var outputresult : Double = 0
        var Operator = "+"
        
        override func viewDidLoad() {
            super.viewDidLoad()
        }
        
        @IBAction func AllClearScreen(_ sender: UIButton) {
            x=0
            y=0
            displayOutlet.text=""
        }
        
        @IBAction func ClrScr(_ sender: UIButton) {
            displayOutlet.text=""
        }
        
        @IBAction func ChgSign(_ sender: UIButton) {
            if(displayOutlet.text?.first=="-"){
                displayOutlet.text?.removeFirst()
            }
            else{
                displayOutlet.text="-\(displayOutlet.text!)"
            }
        }
        
        @IBAction func buttonDivide(_ sender: UIButton) {
            Operator = "/"
            x = Double(displayOutlet.text!)!
            displayOutlet.text=""
        }
        
        @IBAction func buttonMultiply(_ sender: UIButton) {
            Operator = "*"
            x = Double(displayOutlet.text!)!
            displayOutlet.text=""
        }
        
        @IBAction func buttonSubstract(_ sender: UIButton) {
            Operator = "-"
            x = Double(displayOutlet.text!)!
            displayOutlet.text=""
        }
        
        @IBAction func buttonAddition(_ sender: UIButton) {
            Operator = "+"
            x = Double(displayOutlet.text!)!
            displayOutlet.text=""
        }
        
        @IBAction func buttonEquals(_ sender: UIButton) {
            y = Double(displayOutlet.text!)!
                    switch Operator {
                    case "+":
                        outputresult = x+y
                        displayOutlet.text = String(outputresult)
                    case "-":
                        outputresult = x-y
                        displayOutlet.text = String(outputresult)
                    case "*":
                        outputresult = x*y
                        displayOutlet.text = String(outputresult)
                    case "/":
                        outputresult = x/y
                        if(y==0){
                            displayOutlet.text="Error"
                        }
                        else{
                        let result1=round(outputresult*100000)/100000
                        displayOutlet.text = String(result1)
                        }
                    case "%":
                        outputresult = x.truncatingRemainder(dividingBy: y)
                        let result=round(outputresult*10)/10
                        displayOutlet.text = String(result)
                    default:
                        displayOutlet.text = "ERROR"
        }
            let splitOutput =  displayOutlet.text!.components(separatedBy: ".")
            let test = displayOutlet.text
            if(!(test == "Error")){
            if(splitOutput[1]=="0"){
                displayOutlet.text = splitOutput[0]
            }
            }
        }
        
        @IBAction func buttonPercentage(_ sender: UIButton) {
            Operator = "%"
            x = Double(displayOutlet.text!)!
            displayOutlet.text=""
        }
        
        @IBAction func buttonDecimal(_ sender: UIButton) {
            
           if(!displayOutlet.text!.contains("."))
            {
               displayOutlet.text = displayOutlet.text! + "."
                return
            }
        }
        
        @IBAction func buttonZero(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "0"
        }
        
        @IBAction func buttonOne(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "1"
        }
        
        @IBAction func buttonTwo(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "2"
        }
        
        @IBAction func buttonThree(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "3"
        }
        
        @IBAction func buttonFour(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "4"
        }
        
        @IBAction func buttonFive(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "5"
        }
        
        @IBAction func buttonSix(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "6"
        }
        
        @IBAction func buttonSeven(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "7"
        }
        
        @IBAction func buttonEight(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "8"
        }
        
        @IBAction func buttonNine(_ sender: UIButton) {
            displayOutlet.text = displayOutlet.text! + "9"
        }

    }



