//
//  ViewController.swift
//  Kodipelly_Calculator
//
//  Created by Kodipelly,Sravani on 2/16/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

