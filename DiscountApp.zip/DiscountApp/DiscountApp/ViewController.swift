//
//  ViewController.swift
//  DiscountApp
//
//  Created by Kodipelly,Sravani on 2/15/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var EnterAmountoutlet: UITextField!
    
    @IBOutlet weak var EnterDiscountoutlet: UITextField!
    
    
    @IBOutlet weak var DisplayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Submitbutton(_ sender: Any) {
        var EnteredAmount = Double(EnterAmountoutlet.text!)
        var EnteredDiscount = Double(EnterDiscountoutlet.text!)
        
        var priceAfterDiscount = (EnteredAmount!-(EnteredAmount!-EnteredDiscount!)/100)
        DisplayLabel.text = "price after Discount is : \(priceAfterDiscount)"
            
        }
    }
    


