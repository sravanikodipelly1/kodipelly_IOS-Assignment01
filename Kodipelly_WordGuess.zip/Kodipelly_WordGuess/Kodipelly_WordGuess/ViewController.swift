//
//  ViewController.swift
//  Kodipelly_WordGuess
//
//  Created by Sravani, Kodipelly on 3/28/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsMissedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessALetterButton: UIButton!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    var words = [["DIAMOND", "Material used for Ornaments"],
                 ["GUITAR", "Musical Instrument"],
                 ["LADDOO", "Sweet"],
                 ["ROSE","Flower"],
                 ["SCOOTER","Two-Wheeler"]]
    var images = ["diamond","guitar","laddoo","rose","scooter","tryagain"]
    
    var cnt = 0
    var lettersGuessed = ""
    var word = ""
    var guessCount = 0
    var maximumNumberOfWrongGuesses = 10
    var letter1 = ""
    var letter2 = ""
    var letter3 = ""
    var cnt1 = 0
    var cnt2 = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        guessALetterButton.isEnabled = false
        word = words[cnt][0]
        userGuessLabel.text = ""
        letter1 = wordsGuessedLabel.text!
        letter2 = wordsMissedLabel.text!
        letter3 = wordsRemainingLabel.text!
        totalWordsLabel.text = totalWordsLabel.text!+String(words.count)
        wordsGuessedLabel.text = letter1+String(cnt)
        wordsRemainingLabel.text = letter3+String(words.count)
        wordsMissedLabel.text = letter2+String(cnt)
        updateUnderscores();
        hintLabel.text = "Hint: "+words[cnt][1]
        
    }
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        let guessletter = guessLetterField.text!
        guessLetterField.resignFirstResponder()
        lettersGuessed = lettersGuessed + guessletter
        var revealedLetterInWord = ""
        for l in word{
            if lettersGuessed.contains(l){
                revealedLetterInWord += "\(l)"
            }
            else{
                revealedLetterInWord += "_ "
            }
            
        }
        guessCount = guessCount + 1
        guessCountLabel.text = "You have made \(guessCount)  Guesses";
        maximumNumberOfWrongGuesses = maximumNumberOfWrongGuesses - 1
        userGuessLabel.text = revealedLetterInWord
        guessLetterField.text = ""
        if (userGuessLabel.text!.contains("_") == false){
            cnt += 1
            guessCountLabel.text = "You won! it took you \(guessCount) attemps to guess the word!";
            guessLetterField.isEnabled = false
            cnt1 = cnt1 + 1
            wordsGuessedLabel.text = letter1+String(cnt1)
            wordsMissedLabel.text = letter2+String(cnt2)
            wordsRemainingLabel.text = letter3+String((words.count) - cnt)
            maximumNumberOfWrongGuesses = 10
            guessCount = 0
            playAgainButton.isHidden = false;
            guessALetterButton.isEnabled = false;
            imageViewOutlet.image = UIImage(named: images[cnt-1])
            UIView.animate(withDuration: 1, delay: 0,
                           usingSpringWithDamping: 0.2, initialSpringVelocity: 1,
                           animations: {
                self.imageViewOutlet.frame.origin.x = -200
                self.imageViewOutlet.frame.origin.y = -400
                self.imageViewOutlet.image = UIImage(named: self.images[self.cnt-1])
            },completion: {_ in
                self.imageViewOutlet.frame.origin.x = 80
                self.imageViewOutlet.frame.origin.y = 550
            })
            if (cnt == words.count){
                guessCountLabel.text = "You have tried all the words! Restart from the beginnning?"
                cnt1 = 0
                cnt2 = 0
                cnt = 0
            }
            
        }
        if(maximumNumberOfWrongGuesses == 0 && userGuessLabel.text!.contains("_") == true){
            cnt += 1
            guessCount = 0
            cnt2 = cnt2 + 1
            guessCountLabel.text = "You have used all the available guesses, Please start again";
            guessLetterField.isEnabled = false
            wordsGuessedLabel.text = letter1+String(cnt1)
            wordsMissedLabel.text = letter2+String(cnt2)
            wordsRemainingLabel.text = letter3+String((words.count) - cnt)
            maximumNumberOfWrongGuesses = 10
            playAgainButton.isHidden = false;
            guessALetterButton.isEnabled = false;
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 1,
                           animations: {
                self.imageViewOutlet.frame.origin.x = -200
                self.imageViewOutlet.frame.origin.y = -100
                self.imageViewOutlet.image = UIImage(named: self.images[5])
            },completion: {_ in
                self.imageViewOutlet.frame.origin.x = 80
                self.imageViewOutlet.frame.origin.y = 550
            })
            if (cnt == words.count){
                guessCountLabel.text = "You have tried all the words! Restart from the beginnning?"
                cnt1 = 0
                cnt2 = 0
                cnt = 0
            }
        }
        guessALetterButton.isEnabled = false
    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        playAgainButton.isHidden = true
        imageViewOutlet.image = UIImage(named: "")
        lettersGuessed = ""
        wordsRemainingLabel.text = letter3+String((words.count) - cnt)
        if(cnt == 0){
            word = words[cnt][0]
            userGuessLabel.text = ""
            updateUnderscores()
            guessLetterField.isEnabled = true
            hintLabel.text = "Hint: "
            hintLabel.text! += words[cnt][1]
            wordsGuessedLabel.text = letter1+String(cnt1)
            wordsMissedLabel.text = letter2+String(cnt2)
            wordsRemainingLabel.text = letter3+String((words.count) - cnt)
            guessCountLabel.text = "You have made \(guessCount)  Guesses";
        }
        else{
            word = words[cnt][0]
            guessCountLabel.text = "You have made \(guessCount)  Guesses";
            guessLetterField.isEnabled = true
            hintLabel.text = "Hint: "
            hintLabel.text! += words[cnt][1]
            guessALetterButton.isEnabled = false
            userGuessLabel.text = ""
            updateUnderscores()
        }
        
    }
    
    @IBAction func guessLFAction(_ sender: UITextField) {
        var letterGuessed = guessLetterField.text!;
        letterGuessed = String(letterGuessed.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = letterGuessed
        if letterGuessed.isEmpty{
            guessALetterButton.isEnabled = false
        }
        else{
            guessALetterButton.isEnabled = true
        }
    }
    
    func updateUnderscores(){
        for _ in word{
            userGuessLabel.text! += "_ "
        }
    }
    
}
