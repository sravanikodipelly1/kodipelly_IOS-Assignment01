//
//  XylophoneViewController.swift
//  MusicPlay
//
//  Created by student on 4/4/22.
//

import UIKit
import AVFoundation
class XylophoneVC: UIViewController {

    var player: AVAudioPlayer?
    
    var soundFiles = ["note1", "note2", "note3", "note4", "note5", "note6", "note7"]
    
    var playsoundTag = ""
    override func viewDidLoad() {
        super.viewDidLoad()
    }

 
    @IBAction func notePressed(_ sender: UIButton) {
        playsoundTag = soundFiles[sender.tag - 1]
        playSound()
        
    }
    
    func playSound() {
        guard let url = Bundle.main.url(forResource: playsoundTag, withExtension: "wav") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
