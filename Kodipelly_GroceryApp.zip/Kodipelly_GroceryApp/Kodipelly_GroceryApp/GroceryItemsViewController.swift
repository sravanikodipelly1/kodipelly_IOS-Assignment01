//
//  GroceryItemsViewController.swift
//  Kodipelly_GroceryApp
//
//  Created by student on 4/11/22.
//

import UIKit

class GroceryItemsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    var grocery = GrocerySections()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        grocery.items_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = groceryItemsTableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath)
                cell.textLabel!.text = grocery.items_Array[indexPath.row].itemName
                return cell
    }
    

    @IBOutlet weak var groceryItemsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        groceryItemsTableView.delegate = self
        groceryItemsTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemInfoSegue"{
            let destination = segue.destination as! ItemInfoViewController
            destination.grocery_item = grocery.items_Array[(groceryItemsTableView.indexPathForSelectedRow?.row)!]
    }
    }
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


