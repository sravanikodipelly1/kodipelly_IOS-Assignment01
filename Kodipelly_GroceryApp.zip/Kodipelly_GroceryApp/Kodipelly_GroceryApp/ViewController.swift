//
//  ViewController.swift
//  Kodipelly_GroceryApp
//
//  Created by Kodipelly,Sravani on 4/5/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var grocerySectionsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

