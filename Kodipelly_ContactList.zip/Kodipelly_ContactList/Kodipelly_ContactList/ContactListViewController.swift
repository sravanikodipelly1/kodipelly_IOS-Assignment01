//
//  ViewController.swift
//  Kodipelly_ContactList
//
//  Created by student on 4/26/22.
//

import UIKit

class ContactListViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

