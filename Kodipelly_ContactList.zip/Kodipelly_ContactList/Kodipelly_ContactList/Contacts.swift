//
//  Contacts.swift
//  Kodipelly_ContactList
//
//  Created by student on 4/26/22.
//

import Foundation

var contacts = [["John","6612346543"],["Micheal","7654321786"],["Kevin","9087543157"],["Eden","8976543219"],["Rodrygo","7896543261"],["Adam","6578943219"],["Gabriel","6543216891"],["Mary","6123456789"]]

