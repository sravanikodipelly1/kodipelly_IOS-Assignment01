//
//  ViewController.swift
//  even number app
//
//  Created by Kodipelly,Sravani on 2/8/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textoutlet: UITextField!
    
    
    
    
    @IBOutlet weak var labeloutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

   
    
    @IBAction func buttonclicked(_ sender: Any) {
        let input = Int(textoutlet.text!)
        if(input!%2 == 0){
            labeloutlet.text = "\(input!) is even number"
        }
        else{
            labeloutlet.text = "\(input!) is odd number"
        }
    }
    
}

